package com.cg.fms.pl;

import java.util.Scanner;

public class Client {

	public static void main(String[] args) {
		
		AdminConsole adminConsole=new AdminConsole();
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("1. update course");
			System.out.println("2. view All courses");
			System.out.println("3. Exit");
			System.out.println("enter choice");
			int choice =sc.nextInt();
			switch(choice)
			{
			case 1: adminConsole.UpdateCourse();
					break;
			case 2: adminConsole.viewAllCourses();
					break;
			case 3: System.exit(0);
			}
		}
	}
}
