package com.cg.fms.pl;

import java.util.List;
import java.util.Scanner;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.service.AdminServiceImpl;
import com.cg.fms.service.IAdminService;

public class AdminConsole {

	IAdminService service=new AdminServiceImpl();
	CourseBean bean=new CourseBean();
	Scanner sc=new Scanner(System.in);
	
	public void viewAllCourses()
	{
		try {
			List<CourseBean> list=service.viewAllCourses();
			if(list.isEmpty())
			{
				System.out.println("No Courses found");
			}
			else
			{
				for(CourseBean bean:list)
				{
					System.out.println(bean.toString());
				}
			}
		} catch (FeedbackException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void UpdateCourse()
	{
		System.out.println("Enter Course ID");
		int id=sc.nextInt();
		System.out.println("Enter Course Name");
		String name=sc.next();
		System.out.println("Enter No of Days");
		int days=sc.nextInt();
		bean.setCourseId(id);
		bean.setCourseName(name);
		bean.setDays(days);
		try {
			boolean flag=service.updateCourse(bean);
			if(flag)
			{
				System.out.println("Updated Successfully");
			}
			else
			{
				System.out.println("Invalid Course ID");
			}
		} catch (FeedbackException e) {
				
				System.out.println(e.getMessage());
		}
	}
}
