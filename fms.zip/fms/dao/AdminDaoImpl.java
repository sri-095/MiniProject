package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.util.DBConnection;

public class AdminDaoImpl implements IAdminDao {

	@Override
	public List<CourseBean> viewAllCourses() throws FeedbackException {

		List<CourseBean> list = new ArrayList<CourseBean>();
		Connection con = DBConnection.getConnection();
		try {
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.SELECT_COURSES);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				CourseBean bean = new CourseBean();
				bean.setCourseId(rs.getInt("course_id"));
				bean.setCourseName(rs.getString("course_name"));
				bean.setDays(rs.getInt("days"));
				list.add(bean);
			}
			con.close();
		} catch (SQLException e) {

			throw new FeedbackException("Unable to fetch records");
		}
		return list;
	}

	@Override
	public boolean updateCourse(CourseBean bean) throws FeedbackException {

		boolean flag = false;
		Connection con = DBConnection.getConnection();
		try {
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.UPDATE_COURSE);
			pstmt.setString(1, bean.getCourseName());
			pstmt.setInt(2, bean.getDays());
			pstmt.setInt(3, bean.getCourseId());
			int count = pstmt.executeUpdate();
			if (count > 0) {
				flag = true;
			}
			con.close();
		} catch (SQLException e) {

			throw new FeedbackException("Unable to Update");
		}

		return flag;
	}

}
