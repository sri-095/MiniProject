package com.cg.fms.dao;

public class QueryMapper {

	public static final String UPDATE_COURSE="update course_master set course_name=?,days=? where course_id=?";
	public static final String SELECT_COURSES="select course_id,course_name,days from course_master";
}
