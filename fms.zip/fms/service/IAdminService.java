package com.cg.fms.service;

import java.util.List;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.exception.FeedbackException;

public interface IAdminService {

		public List<CourseBean> viewAllCourses() throws FeedbackException;
		public boolean updateCourse(CourseBean bean) throws FeedbackException;
		
}
