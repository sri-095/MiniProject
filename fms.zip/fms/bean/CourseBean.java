package com.cg.fms.bean;

public class CourseBean {

	private int courseId;
	private String courseName;
	private int days;
	
	
	
	public int getCourseId() {
		return courseId;
	}



	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}



	public String getCourseName() {
		return courseName;
	}



	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}



	public int getDays() {
		return days;
	}



	public void setDays(int days) {
		this.days = days;
	}



	@Override
	public String toString() {
		return "CourseBean [courseId=" + courseId + ", courseName=" + courseName + ", days=" + days + "]";
	}



	public CourseBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
